module DailiesHelper
end
