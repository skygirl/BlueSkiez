require 'test_helper'

class DailiesHelperTest < ActionView::TestCase
end
