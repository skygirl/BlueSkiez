class Promotion < ActiveRecord::Base
end
