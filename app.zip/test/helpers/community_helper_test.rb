require 'test_helper'

class CommunityHelperTest < ActionView::TestCase
end
