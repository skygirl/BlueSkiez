require 'test_helper'

class ManifestsHelperTest < ActionView::TestCase
end
