require 'test_helper'

class PromotionsHelperTest < ActionView::TestCase
end
