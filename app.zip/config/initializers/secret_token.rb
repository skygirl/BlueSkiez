# Be sure to restart your server when you modify this file.

# Your secret key is used for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!

# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
# You can use `rake secret` to generate a secure secret key.

# Make sure your secret_key_base is kept private
# if you're sharing your code publicly.
Blueskies::Application.config.secret_key_base = '7381dacc3856a58c0367d0938ebe2a59ab9e6b25fb11747216d255e98a8df77eedb131dc4f26fe4d9a9487f2e42dd1b6c9bac3d322064ed7b02e4f03a743955e'
